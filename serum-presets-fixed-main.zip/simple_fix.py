import pathlib
import json
import os

# Папка с оригинальными .SerumPreset (из разархивированного пака)
folder = pathlib.Path("Presets")  

fixed_folder = pathlib.Path("Presets_Fixed")
fixed_folder.mkdir(exist_ok=True)

print(f"Найдено пресетов: {len(list(folder.glob('*.SerumPreset')))}\n")

for file in folder.glob("*.SerumPreset"):
    print(f"Обрабатываю: {file.name}")
    
    json_file = file.with_suffix(".json")
    
    # Распаковка
    result = os.system(f'python cli.py unpack "{file}" "{json_file}"')
    
    if not json_file.exists():
        print("   ❌ Не удалось распаковать")
        continue
    
    # Читаем JSON
    with open(json_file, "r", encoding="utf-8", errors="replace") as f:
        data = json.load(f)
    
    # Функция замены версии во всех местах
    def fix_version(obj):
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if isinstance(v, str):
                    if "2.0.24" in v or "2.0.25" in v or "2.0.26" in v:
                        obj[k] = v.replace("2.0.24", "2.0.23").replace("2.0.25", "2.0.23").replace("2.0.26", "2.0.23")
                else:
                    fix_version(v)
        elif isinstance(obj, list):
            for item in obj:
                fix_version(item)
    
    fix_version(data)
    
    # Сохраняем JSON
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    # Запаковываем обратно
    fixed_file = fixed_folder / file.name
    os.system(f'python cli.py pack "{json_file}" "{fixed_file}"')
    
    if fixed_file.exists():
        print("   ✅ Успешно исправлен")
    else:
        print("   ❌ Ошибка при запаковке")

print("\n✅ Готово! Исправленные файлы находятся в папке: Presets_Fixed")