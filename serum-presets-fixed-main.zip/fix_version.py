import pathlib
import json
import os
import shutil

# === НАСТРОЙКИ ===
presets_folder = pathlib.Path("Presets")          # ← измени, если папка называется иначе
fixed_folder = pathlib.Path("Presets_Fixed")
fixed_folder.mkdir(parents=True, exist_ok=True)

print(f"Рабочая папка скрипта: {pathlib.Path.cwd()}")
print(f"Ищем пресеты в: {presets_folder.resolve()}\n")

if not presets_folder.exists():
    print("❌ Папка 'Presets' не найдена! Проверь путь.")
    exit()

success = 0
total = 0

# Рекурсивный поиск
found_files = list(presets_folder.rglob("*.SerumPreset"))

print(f"Найдено .SerumPreset файлов: {len(found_files)}\n")

for file in found_files:
    total += 1
    rel_path = file.relative_to(presets_folder)
    print(f"Обрабатываю: {rel_path}")
    
    # Создаём такую же структуру папок в Presets_Fixed
    target_folder = fixed_folder / rel_path.parent
    target_folder.mkdir(parents=True, exist_ok=True)
    
    json_file = file.with_suffix(".json")
    
    # Распаковка
    print("   → Распаковка...")
    os.system(f'python cli.py unpack "{file}" "{json_file}" > nul 2>&1')
    
    if not json_file.exists() or json_file.stat().st_size < 100:
        print("   ❌ Не удалось распаковать")
        if json_file.exists():
            json_file.unlink()
        continue
    
    # Читаем JSON
    try:
        with open(json_file, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except Exception as e:
        print("   ❌ Ошибка чтения JSON")
        if json_file.exists():
            json_file.unlink()
        continue
    
    # Исправление версии
    def fix_version(obj):
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if isinstance(v, str):
                    if any(x in v for x in ["2.0.24", "2.0.25", "2.0.26"]):
                        obj[k] = v.replace("2.0.24", "2.0.23") \
                                 .replace("2.0.25", "2.0.23") \
                                 .replace("2.0.26", "2.0.23")
                else:
                    fix_version(v)
        elif isinstance(obj, list):
            for i in range(len(obj)):
                fix_version(obj[i])
    
    fix_version(data)
    
    # Сохраняем
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    # Запаковываем обратно
    fixed_file = target_folder / file.name
    print("   → Запаковка...")
    os.system(f'python cli.py pack "{json_file}" "{fixed_file}" > nul 2>&1')
    
    # Удаляем временный json
    if json_file.exists():
        json_file.unlink()
    
    if fixed_file.exists() and fixed_file.stat().st_size > 1000:
        print("   ✅ Успешно")
        success += 1
    else:
        print("   ❌ Ошибка запаковки")

print("\n" + "="*60)
print(f"🎉 ГОТОВО!")
print(f"Всего найдено пресетов: {total}")
print(f"Успешно исправлено: {success}")
if success > 0:
    print(f"✅ Исправленные файлы находятся в: {fixed_folder.resolve()}")
else:
    print("⚠️  Ни один пресет не был обработан. Смотри ошибки выше.")
print("="*60)