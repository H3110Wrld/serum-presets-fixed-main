import pathlib
import json
import os

folder = pathlib.Path("Presets")
fixed_folder = pathlib.Path("Presets_Fixed")
fixed_folder.mkdir(exist_ok=True)

print(f"Всего пресетов: {len(list(folder.glob('*.SerumPreset')))}\n")

success = 0

for file in list(folder.glob('*.SerumPreset'))[:5]:   # Сначала только 5 файлов для теста
    print(f"🔄 Тестирую: {file.name}")
    
    json_file = file.with_suffix(".json")
    
    # Распаковка
    os.system(f'python cli.py unpack "{file}" "{json_file}" > nul 2>&1')
    
    if not json_file.exists() or json_file.stat().st_size == 0:
        print("   ❌ Не распаковался")
        continue
    
    # Читаем JSON
    try:
        with open(json_file, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except:
        print("   ❌ Ошибка чтения JSON")
        continue
    
    # Меняем версию
    def fix_version(obj):
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if isinstance(v, str) and ("2.0.2" in v):
                    obj[k] = v.replace("2.0.24", "2.0.23").replace("2.0.25", "2.0.23").replace("2.0.26", "2.0.23")
                else:
                    fix_version(v)
        elif isinstance(obj, list):
            for item in obj:
                fix_version(item)
    
    fix_version(data)
    
    # Сохраняем
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    # Запаковываем
    fixed_file = fixed_folder / file.name
    os.system(f'python cli.py pack "{json_file}" "{fixed_file}" > nul 2>&1')
    
    if fixed_file.exists() and fixed_file.stat().st_size > 1000:
        print("   ✅ Успешно")
        success += 1
    else:
        print("   ❌ Не запаковался")

print(f"\nГотово! Успешно обработано: {success} из 5")
print(f"Проверь папку: {fixed_folder}")